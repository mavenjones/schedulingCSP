#ifndef _VALUE_H_
#define _VALUE_H_

typedef enum { ij, ji } value;

#endif
